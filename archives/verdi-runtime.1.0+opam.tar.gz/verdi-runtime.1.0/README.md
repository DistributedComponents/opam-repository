Verdi framework runtime library
